import pyautogui
from time import sleep
import keyboard
from random import randint
import base64
data = "Q3JlYXRlZCBCeTogQ3JhY2tvMjk4" ; data1 = base64.b64decode(data) ; data0 = data1.decode('utf-8') ;


print(data0) ; print(" ")

while 1==1:

    Zombie0 = pyautogui.locateOnScreen('_zombie-assets\z0.png', confidence=0.52) # Image Batch #1
    Zombie1 = pyautogui.locateOnScreen('_zombie-assets\z1.png', confidence=0.52)
    Zombie2 = pyautogui.locateOnScreen('_zombie-assets\z2.png', confidence=0.52)
    Zombie3 = pyautogui.locateOnScreen('_zombie-assets\z3.png', confidence=0.52)
    Zombie4 = pyautogui.locateOnScreen('_zombie-assets\z4.png', confidence=0.52)
    Zombie5 = pyautogui.locateOnScreen('_zombie-assets\z5.png', confidence=0.52)
    Zombie6 = pyautogui.locateOnScreen('_zombie-assets\z6.png', confidence=0.52)
    Zombie7 = pyautogui.locateOnScreen('_zombie-assets\z7.png', confidence=0.52)
    Zombie8 = pyautogui.locateOnScreen('_zombie-assets\z8.png', confidence=0.52)
    Zombie9 = pyautogui.locateOnScreen('_zombie-assets\z9.png', confidence=0.52)


    Zombie10 = pyautogui.locateOnScreen('_zombie-assets\z10.png', confidence=0.52) #Image Batch #2
    Zombie11 = pyautogui.locateOnScreen('_zombie-assets\z11.png', confidence=0.52)
    Zombie12 = pyautogui.locateOnScreen('_zombie-assets\z12.png', confidence=0.52)
    Zombie13 = pyautogui.locateOnScreen('_zombie-assets\z13.png', confidence=0.52)

    if Zombie0 != None:
        print("Spotted Zombie.")
        pyautogui.mouseDown(button='right')
        pyautogui.moveTo(Zombie0)
        pyautogui.click(button='left')
        pyautogui.mouseUp(button='right')

    if Zombie1 != None:
        print("Spotted Zombie.")
        pyautogui.mouseDown(button='right')
        pyautogui.moveTo(Zombie1)
        pyautogui.click(button='left')
        pyautogui.mouseUp(button='right')

    if Zombie2 != None:
        print("Spotted Zombie.")
        pyautogui.mouseDown(button='right')
        pyautogui.moveTo(Zombie2)
        pyautogui.click(button='left')
        pyautogui.mouseUp(button='right')

    if Zombie3 != None:
        print("Spotted Zombie.")
        pyautogui.mouseDown(button='right')
        pyautogui.moveTo(Zombie3)
        pyautogui.click(button='left')
        pyautogui.mouseUp(button='right')

    if Zombie4 != None:
        print("Spotted Zombie.")
        pyautogui.mouseDown(button='right')
        pyautogui.moveTo(Zombie4)
        pyautogui.click(button='left')
        pyautogui.mouseUp(button='right')

    if Zombie5 != None:
        print("Spotted Zombie.")
        pyautogui.mouseDown(button='right')
        pyautogui.moveTo(Zombie5)
        pyautogui.click(button='left')
        pyautogui.mouseUp(button='right')

    if Zombie6 != None:
        print("Spotted Zombie.")
        pyautogui.mouseDown(button='right')
        pyautogui.moveTo(Zombie6)
        pyautogui.click(button='left')
        pyautogui.mouseUp(button='right')

    if Zombie7 != None:
        print("Spotted Zombie.")
        pyautogui.mouseDown(button='right')
        pyautogui.moveTo(Zombie7)
        pyautogui.click(button='left')
        pyautogui.mouseUp(button='right')

    if Zombie8 != None:
        print("Spotted Zombie.")
        pyautogui.mouseDown(button='right')
        pyautogui.moveTo(Zombie8)
        pyautogui.click(button='left')
        pyautogui.mouseUp(button='right')

    if Zombie9 != None:
        print("Spotted Zombie.")
        pyautogui.mouseDown(button='right')
        pyautogui.moveTo(Zombie9)
        pyautogui.click(button='left')
        pyautogui.mouseUp(button='right')


        # Second AI Image Batch Done!

    if Zombie10 != None:
        print("Spotted Zombie.")
        pyautogui.mouseDown(button='right')
        pyautogui.moveTo(Zombie10)
        pyautogui.click(button='left')
        pyautogui.mouseUp(button='right')

    if Zombie11 != None:
        print("Spotted Zombie.")
        pyautogui.mouseDown(button='right')
        pyautogui.moveTo(Zombie11)
        pyautogui.click(button='left')
        pyautogui.mouseUp(button='right')

    if Zombie12 != None:
        print("Spotted Zombie.")
        pyautogui.mouseDown(button='right')
        pyautogui.moveTo(Zombie12)
        pyautogui.click(button='left')
        pyautogui.mouseUp(button='right')

    if Zombie13 != None:
        print("Spotted Zombie.")
        pyautogui.mouseDown(button='right')
        pyautogui.moveTo(Zombie13)
        pyautogui.click(button='left')
        pyautogui.mouseUp(button='right')
    sleep(0.52)